#!/usr/bin/env python3
"""
Luraph v15.1 Discord Deobfuscator Bot
Upload a .lua file → get analysis + payload extraction
"""

import os
import re
import io
import hashlib
from typing import Dict, List, Tuple

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    raise SystemExit("DISCORD_TOKEN missing. Put it in .env or environment.")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)


class LuraphAnalyzer:
    HEADER = re.compile(r"Luraph Obfuscator v15\.1", re.I)
    ENTRY = re.compile(r"\}\s*,\s*\{\s*\}\s*\)\s*:\s*([A-Za-z0-9_]+)\s*\(\s*\)", re.S)
    LONG_STR = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\[(=*)\[(.*?)\]\2\]", re.S)

    CALL_OPS = {
        1: "void call",
        25: "call + return",
        27: "multi-return call",
        33: "3-arg call",
        48: "fixed-arg call (store)",
        49: "void call (alt)",
    }

    def __init__(self, src: str, name: str):
        self.src = src
        self.name = name
        self.size = len(src.encode("utf-8", "ignore"))

    def run(self) -> Dict:
        if not self.HEADER.search(self.src) and "setmetatable" not in self.src:
            return {"ok": False, "err": "Not Luraph v15.1"}

        entry = "unknown"
        m = self.ENTRY.search(self.src)
        if m:
            entry = m.group(1)

        target = "Roblox / Luau" if any(x in self.src for x in ("Color3", "Vector2", "UDim", "vector.create")) else "Pure Lua / Unknown"

        payloads: List[Tuple[str, str]] = []
        for m in self.LONG_STR.finditer(self.src):
            name, content = m.group(1), m.group(3)
            if len(content) > 180:
                payloads.append((name, content))

        calls = [f"`{op}` → {desc}" for op, desc in self.CALL_OPS.items() if re.search(rf"\b{op}\b", self.src)]

        apis = {}
        for api in ("buffer.create", "buffer.readu8", "buffer.writeu8", "bit32.bxor", "bit32.band", "loadstring"):
            c = self.src.count(api)
            if c:
                apis[api] = c

        return {
            "ok": True,
            "name": self.name,
            "size": self.size,
            "sha": hashlib.sha256(self.src.encode("utf-8", "ignore")).hexdigest()[:12],
            "entry": entry,
            "target": target,
            "payloads": payloads,
            "calls": calls,
            "apis": apis,
        }

    def text(self, r: Dict) -> str:
        if not r["ok"]:
            return f"❌ {r['err']}"

        lines = [
            f"**Luraph v15.1 Analysis**",
            "```",
            f"File   : {r['name']}",
            f"Size   : {r['size']:,} bytes",
            f"SHA    : {r['sha']}…",
            f"Entry  : :{r['entry']}()",
            f"Target : {r['target']}",
            f"Payloads: {len(r['payloads'])}",
            "```",
        ]

        if r["calls"]:
            lines.append("**Call opcodes (first-dispatch)**")
            lines.extend(f"• {c}" for c in r["calls"])

        if r["apis"]:
            lines.append("\n**Key APIs**")
            for k, v in sorted(r["apis"].items(), key=lambda x: -x[1])[:6]:
                lines.append(f"• `{k}` × {v}")

        if r["payloads"]:
            lines.append("\n**Payload(s) found** — largest one attached if possible")

        lines.append("\n*Static analysis only. Full auto-devirt of v15.1 needs a dedicated emulator.*")
        return "\n".join(lines)


@bot.event
async def on_ready():
    print(f"Online as {bot.user}")
    try:
        await bot.tree.sync()
        print("Slash commands synced")
    except Exception as e:
        print("Sync error:", e)


@bot.tree.command(name="deobf", description="Analyze a Luraph v15.1 .lua file")
@app_commands.describe(file="The obfuscated .lua file")
async def deobf(interaction: discord.Interaction, file: discord.Attachment):
    await interaction.response.defer(thinking=True)

    if not file.filename.lower().endswith((".lua", ".txt", ".luau")):
        return await interaction.followup.send("Upload a `.lua` / `.luau` / `.txt` file.")

    if file.size > 7_500_000:
        return await interaction.followup.send("File too big (Discord limit).")

    raw = await file.read()
    src = raw.decode("utf-8", "replace")

    az = LuraphAnalyzer(src, file.filename)
    result = az.run()
    msg = az.text(result)

    embed = discord.Embed(
        title="Luraph v15.1 Deobfuscator",
        description=msg[:4000],
        color=0x5865F2 if result["ok"] else 0xED4245,
    )
    await interaction.followup.send(embed=embed)

    # send largest payload if exists and reasonable size
    if result.get("ok") and result["payloads"]:
        biggest = max(result["payloads"], key=lambda x: len(x[1]))
        name, content = biggest
        if 50 < len(content) < 400_000:
            bio = io.BytesIO(content.encode("utf-8", "replace"))
            await interaction.followup.send(
                content=f"📦 Extracted payload `{name}`",
                file=discord.File(bio, filename=f"{name}_payload.txt"),
            )


@bot.tree.command(name="info", description="About this bot")
async def info(interaction: discord.Interaction):
    await interaction.response.send_message(
        "**Luraph v15.1 Deobfuscator**\n"
        "Upload a file with `/deobf`\n\n"
        "Does: detection, entry point, target, call opcodes, payload extraction.\n"
        "Does **not** fully decompile (v15.1 is self-modifying)."
    )


@bot.command()
async def ping(ctx):
    await ctx.send(f"Pong `{round(bot.latency*1000)}ms`")


if __name__ == "__main__":
    bot.run(TOKEN)
