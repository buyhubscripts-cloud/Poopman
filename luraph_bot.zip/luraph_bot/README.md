# Luraph v15.1 Discord Bot

Simple Discord bot that analyzes Luraph v15.1 scripts.

## Commands
- `/deobf` → upload a `.lua` file
- `/info`
- `!ping`

## Setup (phone friendly)

1. Create a bot at https://discord.com/developers/applications
2. Copy the token
3. Put the token in a file called `.env`:
   ```
   DISCORD_TOKEN=your_token_here
   ```
4. Install & run:

```bash
pip install -r requirements.txt
python bot.py
```

### Free hosting (recommended from phone)
- Railway.app
- Render.com
- Just upload this folder + set the `DISCORD_TOKEN` environment variable

## What it does
- Detects Luraph v15.1
- Finds entry point (`:u()`, `:WS()`, etc.)
- Detects Roblox vs pure Lua
- Extracts long string payloads
- Shows first-dispatch call opcodes
- Attaches the largest payload as a file
